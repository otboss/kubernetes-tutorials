## Simple Node.js Server

How to create a simple Node.js server:

- You need Node.js to be installed on your system. You can download Node.js and follow the instructions on how to do that on [nodejs.org](http://nodejs.org/);
- Clone or download this repository;
- Open your terminal;
- With the command line go to the folder you just cloned/downloaded;
- Type 'npm start', so your server start running;
- Go to the browser and access http://127.0.0.1:1337/.
